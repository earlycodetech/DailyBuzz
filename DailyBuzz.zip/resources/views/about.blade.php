@extends('layouts.app')
@section('content')
        <h1>About Us</h1>
        <ul>
            <li>lorem10</li>
            <li>lorem10</li>
            <li>lorem10</li>
            <li>lorem10</li>
            <li>lorem10</li>
        </ul>
@endsection
