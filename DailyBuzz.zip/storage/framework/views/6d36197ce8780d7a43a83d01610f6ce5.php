<?php $__env->startSection('content'); ?>
    <section>
        <div class="container-fluid hero">
            <div class="d-flex justify-content-center align-items-center bg-info" style="background-image: url(<?php echo e(asset('images/video-bg.png')); ?>);">
                <h1> Welcome to Daily Buzz </h1>
            </div>
        </div>
    </section>


    <section>
        <div class="container my-5">
            <div class="row">
                <div class="col-md-6 col-lg-4">
                    <div class="card border-0 shadow">
                        <img src="<?php echo e(asset('images/video-bg.png')); ?>" class="card-img-top" alt="">

                        <div class="card-body">
                            <p class="h4 fw-semibold">
                                This is the title
                            </p>
                            <p class="fw-semibold">
                                Author: Jeremy Smith
                            </p>
                            <p class="fw-semibold">
                                12th Jun. 2023
                            </p>
                            <a href="<?php echo e(url('view')); ?>" class="btn btn-info rounded-pill w-100">
                                Read Post
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Owner\Desktop\Workspace\Earlycode\DailyBuzz\resources\views/welcome.blade.php ENDPATH**/ ?>