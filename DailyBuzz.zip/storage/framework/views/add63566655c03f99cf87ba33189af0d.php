
<?php $__env->startSection('content'); ?>
    <section>
        <div class="container py-5">
            <form action="<?php echo e(route('categories.update', ['category' => $category->slug])); ?>" class="bg-white mx-auto w-50 p-2 p-md-4 shadow" method="post">
                <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>

                
                <?php if($msg =  Session::get('success')): ?>
                    <p class="alert alert-success"> <?php echo e($msg); ?>  </p>
                <?php endif; ?>
                <div class="my-5">
                    <h3>Edit: <?php echo e($category->name); ?></h3>
                </div>
                
                <div class="mb-3">
                    <label for="" class="form-label"> Name </label>
                    <input type="text" value="<?php echo e($category->name); ?>" name="category_name" class="form-control" autofocus>
                    <?php $__errorArgs = ['category_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="small fw-bold text-danger"> Error: <?php echo e($message); ?> </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-3">
                    <button class="btn btn-primary">
                        Edit  Category
                    </button>
                </div>
            </form>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Owner\Desktop\Workspace\Earlycode\DailyBuzz\resources\views/categories/edit.blade.php ENDPATH**/ ?>