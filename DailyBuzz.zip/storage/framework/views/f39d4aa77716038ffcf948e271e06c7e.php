
<?php $__env->startSection('content'); ?>
    <div class="container my-5 bg-white p-5">
        <h3>Create a new post</h3>
        <form action="<?php echo e(route('posts.store')); ?>" enctype="multipart/form-data" method="POST" class="row">
            <?php echo csrf_field(); ?>
            <?php if($msg = Session::get('success')): ?>
                <p class="alert alert-success"> <?php echo e($msg); ?> </p>
            <?php endif; ?>

            <div class="col-md-6 mb-3">
                <label for="">Category</label>
                <select name="category" class="form-select">
                    <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <option value="<?php echo e($cat->id); ?>"> <?php echo e($cat->name); ?> </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <option disabled>No Categories Available</option>
                    <?php endif; ?>
                </select>
                <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="small fw-bold text-danger"> Error: <?php echo e($message); ?> </p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-md-6 mb-3">
                <label for="">Title</label>
                <input type="text" name="title" class="form-control">
                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="small fw-bold text-danger"> Error: <?php echo e($message); ?> </p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-md-6 mb-3">
                <label for="">Cover</label>
                <input type="file" name="cover" capture="" class="form-control">
                <?php $__errorArgs = ['cover'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="small fw-bold text-danger"> Error: <?php echo e($message); ?> </p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-12 mb-3">
                <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="small fw-bold text-danger"> Error: <?php echo e($message); ?> </p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <label for=""> Post </label>
                <textarea name="content" rows="10" class="form-control"></textarea>
            </div>

            <div class="col-12 my-3">
                <button class="btn btn-primary">
                    Create Post
                </button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Owner\Desktop\Workspace\Earlycode\DailyBuzz\resources\views/posts/create.blade.php ENDPATH**/ ?>