
<?php $__env->startSection('content'); ?>
    <section>
        <div class="container bg-white py-5">
            <div class="text-end">
                <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-primary">
                    New Category
                </a>
            </div>


            <div class="my-5 table-responsive">
                
                <?php if($msg =  Session::get('success')): ?>
                    <p class="alert alert-success"> <?php echo e($msg); ?>  </p>
                <?php endif; ?>
                
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="row"> Title </th>
                            <th scope="row"> Date Created </th>
                            <th scope="row"> Last Updated </th>
                            <th scope="row">...</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td> <?php echo e($cat->name); ?> </td>
                                <td> <?php echo e($cat->created_at->format('jS M. Y h:i a')); ?> </td>
                                <td> <?php echo e($cat->updated_at->diffForHumans()); ?> </td>
                                <td class="d-flex gap-3 align-items-center">
                                    <a href="<?php echo e(route('categories.edit', ['category' => $cat->slug])); ?>" class="btn btn-sm btn-primary">Edit</a>
                                    <form action="<?php echo e(route('categories.destroy', ['category' => $cat->slug])); ?>" method="POST" onsubmit="return confirm('Are you sure?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn btn-danger btn-sm">
                                            Delete
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td>No Record Found</td>
                            </tr>
                        <?php endif; ?>

                    </tbody>
                </table>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Owner\Desktop\Workspace\Earlycode\DailyBuzz\resources\views/categories/index.blade.php ENDPATH**/ ?>