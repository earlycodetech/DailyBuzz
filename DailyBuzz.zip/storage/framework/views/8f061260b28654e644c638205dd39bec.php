<?php $__env->startSection('content'); ?>
<section>
    <div class=" contact min-vh-100 my-5">
        <div class="card border-0 shadow mx-auto" style="max-width: 600px;">
            <div class="card-header ">
                <h5 class="text-center "> contact up</h5>
            </div> 
            <div class="card-body bg-secondary">
                <form action="">
                    <div class="mb-3">
                        <label for="" class="form-leble"> FULL NAME</label>
                        <input type="text" class="form-control form-control-lg">
                    </div>
                    <div class="mb-3">
                        <label for="" class="form-leble"> EMAIL</label>
                        <input type="text" class="form-control form-control-lg">
                    </div>
                    <div class="mb-3">
                        <label for="" class="form-leble"> SUBJECT</label>
                        <SElect name="" class="form-select form-select-sm">
                            <option value="">book</option>
                            <option value="">project</option>
                        </SElect>
                    </div>

                    <div class="mb-3">
                        <label for="" class="form-leble"> massage</label>
                        <input type="text" class="form-control form-control-lg">
                        
                    </div>

                    <div class="mb-3">
                        <button class="btn btn-outline-primary">submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Owner\Desktop\Workspace\Earlycode\DailyBuzz\resources\views/contact.blade.php ENDPATH**/ ?>